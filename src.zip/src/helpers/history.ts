import { createBrowserHistory } from "@remix-run/router";

const history = createBrowserHistory({ v5Compat: true });

export default history;
