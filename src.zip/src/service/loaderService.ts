import { Subject } from "rxjs";

export class LoaderOptimus {
  static loader$ = new Subject();
}
