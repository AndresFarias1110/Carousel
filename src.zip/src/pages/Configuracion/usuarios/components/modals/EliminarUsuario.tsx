import React from "react";

export const EliminarUsuario = () => {
  return <div>EliminarUsuario</div>;
};
