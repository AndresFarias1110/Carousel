import "./DcFc.css";
export const DcFc = () => {
  return (
    <div className="fondo-principal">
      <div>
        <h4>Prueba</h4>
        aqui va a ir una caja
      </div>
    </div>
  );
};
