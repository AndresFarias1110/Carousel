export const Inbound = () => {
  return <div>Inbound</div>;
};
