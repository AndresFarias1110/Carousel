export const tiposReportes: string[] = [
  "Descargar Todo",
  "Descargar Selección",
];

export const tiposAcciones: string[] = [
  "Cambio Estatus Operativo",
  "Cambio Estatus Comercial",
];

export const chipOptionsUnidades: string[] = [
  "placas",
  "tipo unidad",
  "categoria",
  "capacidad",
  "arrendador",
  "carrier",
  "estatus comercial",
  "estatus operativo",
  "numero economico",
  "marca",
  "modelo",
  "clase nombre",
  "tipo flota",
  "asignacion operativa",
  "folio contrato",
  "tipo contrato",
  "asignacion financiera",
];

export const months: string[] = [
  "Enero",
  "Febrero",
  "Marzo",
  "Abril",
  "Mayo",
  "Junio",
  "Julio",
  "Agosto",
  "Septiembre",
  "Octubre",
  "Noviembre",
  "Diciembre",
];
