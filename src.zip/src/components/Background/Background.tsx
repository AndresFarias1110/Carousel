import "./Background.css";

export const Background = () => {
  return (
    <div className="container-fluid text-center position-absolute ">
      <div className="row barra"></div>
    </div>
  );
};
