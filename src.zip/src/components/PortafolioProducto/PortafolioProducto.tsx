import { useEffect, useState } from "react";

import iconFlecha from "../../assets/icons/icon-flecha.svg";
import imgOmniDC from "../../assets/img/ProductoSupplyChain/img-dc.png";
import imgInbound from "../../assets/img/ProductoSupplyChain/img-Inbound.png";
import imgOmniTranspotation from "../../assets/img/ProductoSupplyChain/img-transportation.png";
import imgInboundChico from "../../assets/img/ProductoSupplyChain/Inbound-chico.png";
import imgInboundGrande from "../../assets/img/ProductoSupplyChain/inbound-imports.png";
import imgOmniDCChico from "../../assets/img/ProductoSupplyChain/Omni-DC-chico.png";
import imgOmniDCGrande from "../../assets/img/ProductoSupplyChain/img-dc.png";
import imgOmniTranspotationChico from "../../assets/img/ProductoSupplyChain/Omni-Transportation-chico.png";
import imgOmniTranspotationGrande from "../../assets/img/ProductoSupplyChain/img-transportation.png";
import "./PortafolioProducto.css";

const portafoliosInicial = [
  {
    img: imgInboundGrande,
    titulo: "Inbound & Imports",
    activo: false,
    class: "portafolio-img inbound position-relative",
    collapse: false,
    descripcion:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.",
  },
  {
    img: imgOmniDCGrande,
    titulo: "Omni DC & FC",
    activo: false,
    collapse: false,
    class: "portafolio-img omni-dc position-relative",
    descripcion:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.",
  },
  {
    img: imgOmniTranspotationGrande,
    titulo: "Omni Transportation",
    activo: false,
    collapse: false,
    class: "portafolio-img position-relative",
    descripcion:
      "Proporcionar soluciones tecnológicas enfocadas en fortalecer la experiencia de nuestros usuarios de transporte a través de productos y sistema.",
  },
];

export const PortafolioProducto = () => {
  const [current, setCurrent] = useState(-1);
  const [portafolios, setPortafolios] = useState(portafoliosInicial);

  const handleClick = (index: number) => {
    setPortafolios(portafoliosInicial);
    setCurrent(index);
    switch (index) {
      case 0:
        portafolios[index].activo = true;
        portafolios[index].collapse = false;
        // portafolios[index].img = imgInboundGrande;

        // portafolios[1].img = imgOmniDCChico;
        // portafolios[2].img = imgOmniTranspotationChico;

        portafolios[1].activo = false;
        portafolios[1].collapse = true;
        portafolios[2].activo = false;
        portafolios[2].collapse = true;
        break;
      case 1:
        portafolios[index].activo = true;
        // portafolios[index].img = imgOmniDCGrande;
        portafolios[index].collapse = false;

        // portafolios[0].img = imgInboundChico;
        // portafolios[2].img = imgOmniTranspotationChico;

        portafolios[0].activo = false;
        portafolios[0].collapse = true;
        portafolios[2].activo = false;
        portafolios[2].collapse = true;
        break;
      case 2:
        portafolios[index].activo = true;
        // portafolios[index].img = imgOmniTranspotationGrande;
        portafolios[index].collapse = false;

        // portafolios[0].img = imgInboundChico;
        // portafolios[1].img = imgOmniDCChico;

        portafolios[0].activo = false;
        portafolios[0].collapse = true;
        portafolios[1].activo = false;
        portafolios[1].collapse = true;
        break;
    }
  };

  useEffect(() => {}, [current]);

  return (
        <div className="row">
          <div className="col-12 text-center mt-220 mb-4">
            <span className="titulo-seccion">
              Portafolios dentro de la oficina de producto
            </span>
          </div>
          <div className="bar-navigation">
            {portafolios.map((portafolio: any, index: number) => {
              return (
                <div
                  className={
                    portafolio.activo
                      ? `portafolio-nav-list ${portafolio.class} activo`
                      : `portafolio-nav-list ${portafolio.class}`
                  }
                  onClick={() => handleClick(index)}
                >
                    <div className="portafolio-nav-item" style={{
                        "backgroundImage": `url(${portafolio.img})`,
                        "backgroundRepeat": `no-repeat` 
                    }}>

                    </div>
                  {!portafolio.activo && (
                    <span
                      className={
                        portafolio.collapse
                          ? `titulo-blanco-portafolio titulo-portalio-colapsado`
                          : "titulo-blanco-portafolio"
                      }
                    >
                      {portafolio.titulo}
                    </span>
                  )}

                  {/* {portafolio.activo && (
                    <div className="position-absolute detalle-activo">
                      <span>{portafolio.titulo}</span>
                      <p className="descripcion-portafolio">
                        {portafolio.descripcion}
                      </p>
                      <p>
                        <button className="btn btn-primary btn-conoce-mas">
                          Conoce más aquí
                          <img src={iconFlecha} alt="" />
                        </button>
                      </p>
                    </div>
                  )} */}
                  {/* <img src={portafolio.img} alt="" /> */}
                </div>
              );
            })}
          </div>
          {/* <nav className="bar-navigation">
            <ul className="nav-list">
                <li className="nav-item"  style={{ backgroundColor: "red"}}>     
                </li>
                <li className="nav-item"  style={{ backgroundColor: "white"}}></li>
                <li className="nav-item"  style={{ backgroundColor: "blue"}}></li>
            </ul>
            </nav> */}
        </div>
  );
};
